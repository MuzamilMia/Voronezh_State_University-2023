#include<iostream>
#include<fstream>
#include<ostream>
#include<stack>
#include<queue>

//bool cheack_line(std::string line)
//{
//	std::stack<char> st;
//	bool flag = 1;
//	int i = 0;
//	while (i < line.length() && flag)
//	{
//		if (line[i] == '[' || line[i] = ']' || line[i] == '(')
//			st.push(line[i]);
//		else if (line[i] == ')' || line[i] == '}' || line[i] == ']')
//		{
//			if (!st.empty())
//			{
//				switch (line[i])
//				{
//				case ')':
//					flag = st.top() == '(';
//				case '}':
//					flag = st.top() == '{';
//				case ']':
//					flag = st.top() == '[';
//					break;
//				}
//				st.pop();
//			}
//			else
//				flag = 0;
//		}
//		++i;
//	}
//	return flag && st.empty();
//}
//
//void Task_1(std::ifstream& file)
//{
//	std::string line;
//	while (getline(file, line))
//	{
//		std::cout << line << ' ' << (cheack_line(line) ? '+' : '-') << "\n";
//	}
//}

//.....................................................TASK2..................
void print(std::queue<std::string>& q)
{
	while (!q.empty())
	{
		std::cout << q.front() << ' ';
		q.pop();
	}
}

void clear(std::queue<std::string>& q)
{
	while (!q.empty())
		q.pop();
}
void task2(std::ifstream& file)
{
	std::queue<std::string> q;
	std::string word;
	int mx{};
	while (file >> word)
	{
		size_t len{ word.length() };
		if (len > mx)
		{
			mx = len;
			clear(q);
			q.push(word);
		}
		else
		{
			if (len == mx)
				q.push(word);
		}
	}

	print(q);
}
//...............................................................................task3...
const int n = 8;

void task3_1(int martrix[][n], int num)
{
	std::queue<int>q;
	q.push(num);
	q.push(-1);
	int level{};
	while (!q.empty())
	{
		std::cout << level << ": ";
		while (q.front() != -1)
		{
			int i{ q.front() };
			q.pop();
			std::cout << i << ' ';
			for (int j{}; j < n; ++j)
			{
				if (martrix[i][j])
					q.push(j);
			}
		}
		q.pop();
		if (!q.empty())
			q.push(-1);
		
		std::cout << '\n';
		++level;
	}
}
//...............................................................................................
//task3_2
void task3(int martrix[][n], int num)
{
	std::queue<int>q;
	q.push(num);
	int cur{ 1 };
	int level{};
	while (!q.empty())
	{
		std::cout << level << ": ";
		int next{};
		for (int k{0};k<cur;++k)
		{
			int i{ q.front() };
			q.pop();
			std::cout << i << ' ';
			for (int j{}; j < n; ++j)
				if (martrix[i][j])
				{
					q.push(j);
					next++;
				}
		}
		std::cout << '\n';
		++level;
		cur = next;
	}
}


int main()
{
	///task2
	std::ifstream file("myfile.txt");
	task2(file);
	//.........................................................
	//task3
	int matrix[n][n] = {
		{0,0,0,0,0,0,0,0},
		{0,0,1,1,0,0,0,0},
		{0,0,0,0,1,1,0,0},
		{0,0,0,0,0,0,0,1},
		{0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0,0}
	};
	task3(matrix,0);
	//...........................................

	return 0;
}